
<?php $__env->startSection('content'); ?>

<div class="reset">
    <form action="">
    <img src="img/logo.jpeg"/>
        <h3>Reset Password</h3>
        <input type="password" name="password" placeholder="New Password"/>
        <input type="password" name="confirmpassword" placeholder="Confirm Password"/>
        <input type="submit" value="Reset Password"/>
        

    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('validator.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ziki\Documents\app\laravel\riaguess\riaguess_game\resources\views/validator/reset.blade.php ENDPATH**/ ?>