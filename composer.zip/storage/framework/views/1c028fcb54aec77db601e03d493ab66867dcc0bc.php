
<?php $__env->startSection('content'); ?>
<div class="forgot">
    <form action="">
    <img src="img/logo.jpeg"/>
        <h3>Retrieve Password</h3>
        <p class="forgot-p">Enter your username or email below to receive instructions on resetting your password</p>
        <input type="text" name="username" placeholder="Username / email"/>
        
        <input type="submit" value="Retrieve"/>
        

    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('validator.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ziki\Documents\app\laravel\riaguess\riaguess_game\resources\views/validator/forgot.blade.php ENDPATH**/ ?>