
<?php $__env->startSection('content'); ?>
<div class="signup">
    <form>
        <?php echo csrf_field(); ?>
        <img src="img/logo.jpeg"/>
        <h3>Settings</h3>
        <?php $checkDB = 0; ?>
        <?php if (! (count($list2) == 0)): ?>
        <?php $checkDB = 1; ?>
        <div>
        <h4>Waiting...</h4>
        <img src="img/waiting.gif" alt=""/>
        <p><i>please refresh page once a player is assigned to you</i></p>
        <br/>
        <button class="setplayer">Refresh</button>
        
</div>
<?php endif; ?>

<?php if (! (count($list) == 0)): ?>
<?php $checkDB = 1; ?>

        
        
        <div>
        <p class="selectp">Select player to play with</p>
        <table>
            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <tr>
                <td><?php echo e($item->username); ?>Ria</td>
                <td><a class="playgame" href="startGame/<?php echo e($item->username); ?>">Play</a></td>
            </tr>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </table>
</div>

<?php endif; ?>
<?php if($checkDB == 0): ?>
        <div class="noplayer">
        <p>No available player</p>
        <a href="become_player" class="setplayer"s>Become  A Player</a>
        </div>
<?php endif; ?>

        
        
        

    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function(){
    //   $('.setplayer').click(function(){
    //         window.location.reload();
    //   });
       $('.playgame').click(function(){
            const id = $(this).data("id");
            $.ajax({
                url: "startGame"+$id,
                type: 'GET',
                data: {
                    "id" : username
                },
                success: function(data){
                    alert("success");
                }


            }); 
       }); 
    });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('validator.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ziki\Documents\app\laravel\riaguess\riaguess_game\resources\views/validator/settings.blade.php ENDPATH**/ ?>