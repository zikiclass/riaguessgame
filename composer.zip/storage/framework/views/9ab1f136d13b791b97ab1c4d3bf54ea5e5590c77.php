
<?php $__env->startSection('content'); ?>
<div class="dash">
<h3>Ria Guess Game and Score</h3>
<div class="dash-head">
<h4>Score: <span>0</span></h4>
<h4>Player: <span><?php echo e(Auth::user()->username); ?></span></h4>
<a href="logout" class="logout">Logout</a>
</div>
<div class="dash-game">
    <h2 class="game-title" id="title">Gbaye</h2>
    <div class="game-container">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="game-card g<?php echo e($item->game_id); ?>" data-id="<?php echo e($item->game_id); ?>">
    <img src="<?php echo e($item->pix); ?>" />
    <?php if($item->title == ""): ?>
    <p id="cardP">No Title</p>
    <?php endif; ?>
    <?php if($item->title <> ""): ?>
    <p id="cardP"><?php echo e($item->title); ?></p>
    <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
</div>
<h2 class="game-title" id="title">Gbaye</h2>
</div>

<p>- Riaguessgameandscore (v1.0) -<br/> &copy; <?php echo date("Y"); ?> <i>All rights reserved</i></p> 
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function(){
    $('.game-card').click(function(){
        var id = $(this).attr('data-id');
        var title = ".g"+id;
        $('.game-card').css("background-color", "white");
        $('.game-card').css("font-weight", "normal");
        $('.game-card').css("text-transform", "capitalize");


        $(title).css("background-color", "yellow");
       
        $(title).css("font-weight", "bold");
        $(title).css("text-transform", "uppercase");

    });

    $('.game-title').click(function(){
        alert('game time');
    });
});


</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ziki\Documents\app\laravel\riaguess\riaguess_game\resources\views/user/dashboard.blade.php ENDPATH**/ ?>