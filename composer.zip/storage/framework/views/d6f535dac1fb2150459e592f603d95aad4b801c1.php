
<?php $__env->startSection('content'); ?>
<div class="dash">
<h3>Ria Guess Game and Score</h3>
<div class="dash-head">

<h4>Score: <span>
<?php $__currentLoopData = $chkplayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(Auth::user()->username == $score->player1): ?>
<?php echo e($score->player1score); ?>

<?php else: ?>
<?php echo e($score->player2score); ?>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</span></h4>
<h4>Player: <span><?php echo e(Auth::user()->username); ?></span></h4>
<a href="logout" class="logout">Logout</a>
</div>
<div class="dash-game">
    
<?php $__currentLoopData = $chkplayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="time" id="time"><span id="minutes"><?php echo e($time->minutes); ?></span> : <span id="seconds"><?php echo e($time->seconds); ?></span></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    <div id="gameshow">
    <?php echo csrf_field(); ?>
    <?php $__currentLoopData = $chkplayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($chklist->guesstitle == '--' and $chklist->player1 <> Auth::user()->username): ?>
    <h2 class="game-title">&nbsp;</h2>
    <?php else: ?>
    <h2 class="game-title play" id="title"><?php echo e($chklist->strikeword); ?></h2>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <div class="game-container">
        <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="game-card g<?php echo e($item->game_id); ?>" data-id="<?php echo e($item->game_id); ?>">
        
    <img src="<?php echo e($item->pix); ?>" />
    <?php if($item->title == ""): ?>
    <p id="cardP">No Title</p>
    <?php endif; ?>
    <?php if($item->title <> ""): ?>
    <p id="cardP"><?php echo e($item->title); ?></p>
    <?php endif; ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
</div>
<?php $__currentLoopData = $chkplayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chklist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($chklist->guesstitle == '--' && $chklist->player1 <> Auth::user()->username): ?>
    <h2 class="game-title">&nbsp;</h2>
    <?php else: ?>
    <?php echo csrf_field(); ?>
    <h2 class="game-title play" id="title"><?php echo e($chklist->strikeword); ?></h2>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

<div id="gameend">
<h2>End of Game</h2>

<?php $__currentLoopData = $chkplayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(Auth::user()->username == $score->player1): ?>
<?php if((int)$score->player1score < (int)$score->player2score): ?>
<p id="loss">YOU LOSS!</p>
<?php else: ?>
<p id="won">YOU WON!!</p>
<?php endif; ?>
<?php else: ?>
<?php if((int)$score->player2score < (int)$score->player1score): ?>
<p id="loss">YOU LOSS!</p>
<?php else: ?>
<p id="won">YOU WON!!</p>
<?php endif; ?>
<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<h5 class="endscore"><b>SCORE: </b><span>
<?php $__currentLoopData = $chkplayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $score): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(Auth::user()->username == $score->player1): ?>
<?php echo e($score->player1score); ?>

<?php else: ?>
<?php echo e($score->player2score); ?>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</span>

</h5>


<table>
    <thead class="the">
<td>Player 1</td>
<td>Player 2</td>
<td>Score 1</td>
<td>Score 2</td>
</thead>
<?php $__currentLoopData = $chkplayer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gamestats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
<td><?php echo e($gamestats->player1); ?></td>
<td><?php echo e($gamestats->player2); ?></td>
<td><?php echo e($gamestats->player1score); ?></td>
<td><?php echo e($gamestats->player2score); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<div>
<a href="playagain" class="playagain">Play Again / End Game</a>
</div>
</div>
</div>

<p>- Riaguessgameandscore (v1.0) -<br/> &copy; <?php echo date("Y"); ?> <i>All rights reserved</i></p> 
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
<script>
$(document).ready(function(){
    var seconds = document.getElementById("seconds").innerHTML;
    var minutes = document.getElementById("minutes").innerHTML;

    seconds = parseInt(seconds);
    minutes = parseInt(minutes);
    var zero = "0";
    setInterval(
        function()
        {
            
            if(minutes > 0 || seconds > 0){
            
            if(seconds == 0){
            seconds = 60;
            minutes -= 1;
            if(minutes < 10){
                
                document.getElementById("minutes").innerHTML = zero.concat(minutes);
                minutes = zero.concat(minutes);
            }
            else{
            document.getElementById("minutes").innerHTML = minutes;
            }
           }

            var new_secs = seconds - 1;

            seconds = new_secs;
            if(seconds < 10){
                document.getElementById("seconds").innerHTML = zero.concat(seconds);
                seconds = zero.concat(seconds);
            }
            else{
           document.getElementById("seconds").innerHTML = seconds;
            }

            $.ajax({
                url: 'updateTime/'+minutes+'/'+seconds,
                type: 'GET',
                dataType: 'JSON'
            });
            //console.log(new_secs);
           }
           else{
            document.getElementById("gameshow").style.display = "none";
            document.getElementById("time").style.display = "none";
            document.getElementById("gameend").style.display = "block";
           }
        }
        
        ,1000);

    var title_select;
    $('.game-card').click(function(){
        var id = $(this).attr('data-id');
        var title = ".g"+id;
        $('.game-card').css("background-color", "white");
        $('.game-card').css("font-weight", "normal");
        $('.game-card').css("text-transform", "capitalize");


        $(title).css("background-color", "yellow");
       
        $(title).css("font-weight", "bold");
        $(title).css("text-transform", "uppercase");

        title_select = id;

    });

    $('.play').click(function(){
        // alert(title_select);
        var id = title_select;
        
        $.ajax({
            url: 'playgame/'+id,
            type: 'GET',
            dataType: 'JSON',
            headers: {
      'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
    },
            success: function(data){
               if(data.success){
                alert(data.success);
                window.location.reload();
               }
               
               
            }

        });
    });
});


</script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ziki\Documents\app\laravel\riaguess_game\resources\views/user/dashboard.blade.php ENDPATH**/ ?>