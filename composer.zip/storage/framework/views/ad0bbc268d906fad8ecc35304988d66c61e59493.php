
<?php $__env->startSection('content'); ?>
<div class="card-modal"  id="closeMda">

    <div class="card-modal-content">
        <div onclick="closeModal()" class="closeModal">x</div>
    <h2>UPDATE <br/>Game Card</h2>
    <img src="img/profile.png" id="imgView" alt="Game Card"/>
    <form id="form1" enctype="multipart/form-data" method="POST">
        <?php echo csrf_field(); ?>
    <input type="text" id="gameID" name="gameId" hidden />
    <input type="file" id="imgSel" onchange="PreviewImage();" name="imgFile" accept="image/*"/>
    <input type="text"  name="gametitle" placeholder="Title" id="title"/>
    <input type="submit" value="Update"/>
</form>

</div>

</div>
<div class="sidebar">
<div class="logo">
<i class="fa fa-user-circle" aria-hidden="true"></i>
<p>Admin</p>
</div>

<div class="menu">
<ul>
<li><a href="admin"><i class="fa fa-tachometer" aria-hidden="true"></i>
 Dashboard</a></li>
<li class="active"><a href="gametitle"><i class="fa fa-gamepad" aria-hidden="true"></i>
 Game Title</a></li>
<li><a href="viewgames"><i class="fa fa-gamepad" aria-hidden="true"></i>
 View Games</a></li>
<li><a href="players"><i class="fa fa-male" aria-hidden="true"></i>
Users</a></li>
<li><a href="logout"><i class="fa fa-sign-out" aria-hidden="true"></i>
 Logout</a></li> 

</ul>
</div>

</div>
<div class="content">
    <div class="content-body">
    <div class="notif" id="notif">
        <p>Hi Admin!</p>
        <p class="close" onclick="closediv()">x</p>
</div>
<div class="links">
<ul>
<li><a href="admin"><i class="fa fa-tachometer" aria-hidden="true"></i><br/>
 Dashboard</a></li>
<li class="acve"><a href="gametitle"><i class="fa fa-gamepad" aria-hidden="true"></i><br/>
 Game Title</a></li>
<li><a href="viewgames"><i class="fa fa-gamepad" aria-hidden="true"></i><br/>
 View Games</a></li>
<li><a href="players"><i class="fa fa-male" aria-hidden="true"></i>
Users</a></li>
<li><a href="logout"><i class="fa fa-sign-out" aria-hidden="true"></i>
 Logout</a></li> 

</ul>
</div>
<div class="game-cards">
    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="game-card" onclick="openModal()" data-id="<?php echo e($item->game_id); ?>">
    <img src="<?php echo e($item->pix); ?>" />
    <?php if($item->title == ""): ?>
    <p id="cardP">No Title</p>
    <?php endif; ?>
    <?php if($item->title <> ""): ?>
    <p id="cardP"><?php echo e($item->title); ?></p>
    <?php endif; ?>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>



<p class="copyright">- Riaguessgameandscore (v1.0) -<br/> &copy; <?php echo date("Y"); ?> <i>All rights reserved</i></p> 
</div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
var xclose = document.getElementById("closeMda");

    function closediv(){
        var x = document.getElementById("notif");
         x.style.display = "none";
        
        
    }
    function closeModal(){
        xclose.style.display = "none";
    }

    function openModal(){
        // var pText = document.getElementById("cardP").innerHTML;
        // document.getElementById("gcard").innerHTML = pText;
        xclose.style.display = "block";
        
    }

    window.onclick = function(event) {
  if (event.target == xclose) {
    xclose.style.display = "none";
  }
}



function PreviewImage(){
    var oFReader = new FileReader();
    oFReader.readAsDataURL(document.getElementById("imgSel").files[0]);
    oFReader.onload = function(oFREvent){
        document.getElementById("imgView").src = oFREvent.target.result;
    };
}

$(document).ready(function(){
    
  


    $('.game-card').click(function(){
        const id = $(this).attr('data-id');
        $.ajax({
            url: 'gametitledetails/'+id,
            type: 'GET',
            dataType: 'json',
            data: {
                "id" : id
            },
            success: function(data){
                $('#imgView').attr('src',data['info'].pix);
                $('#gameID').attr('value',data['info'].game_id);
                $('#title').attr('value', data['info'].title);
            }
        });
    });

    $('#form1').on('submit', (function (e){
        e.preventDefault();
        $.ajax({
            url: "gametitleupdate",
            type: "POST",
            data: new FormData(this),
            contentType: false,
            cache: false,
            processData: false,
            success: function(data){
                $('#form1')[0].reset();

                window.location.reload();
            }
        });
    }));
});
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ziki\Documents\app\laravel\riaguess_game\resources\views/admin/gametitle.blade.php ENDPATH**/ ?>